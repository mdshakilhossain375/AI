# ShakilAI Student Management System — Audit Report

**Date:** 2026-09-22
**Source:** `student_management_ACTIVE_20260920_174349.zip` (as uploaded)
**Phase:** Audit only — no files were modified. This follows Rule 1 of the Master AI Handover Guide
("Audit first: read the current file/module/route before editing it") before any code is written.

---

## A. What I found

### A1. Real entry point, confirmed
`unified_app.py` is the live server. It ends with:
```python
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=7200, debug=False)
```
This matches the guide's documented port (7200) and LAN binding. It imports the shared Flask `app`
object from `smc_base.py` (`from smc_base import app`) and adds its own routes on top
(`/analytics`, `/website`, `/portal`, `/ai`, `/api/ask`, `/api/admission`, etc.).

`smc_base.py` (7,276 lines, 101 routes) is the core application: students, attendance, results, users,
teachers, classes, fees, exams, routines, notices, admissions, reports, backup, the generic
academy/consultancy CRUD engine, and the Premium Courses module.

### A2. A second, unrelated file also binds port 7200 — collision risk
`unified_server.py` is a small, older stub (a static landing page linking out to `127.0.0.1:5001/8000/7000/7100`,
i.e. the *pre-unification* microservice layout) that **also** calls `app.run(host="0.0.0.0", port=7200)`.
If anyone runs `python unified_server.py` instead of `python unified_app.py` — easy to do by mistake, the
names are one word apart — it will silently bind the correct port and serve this broken legacy stub instead
of the real app, with no error. `unified_server_phase2_backup.py` is an identical duplicate.
**Recommendation:** rename or remove `unified_server.py` so the correct entry point is unambiguous. Not
touched yet — flagging for your decision.

### A3. Historical route-building bug — appears already fixed, but unverified since the fix
The two most recent server logs are genuinely useful evidence:

| Log file | Timestamp | What it shows |
|---|---|---|
| `server_error_before_current_test.log` | 2026-09-19 22:16 | `/`, `/login` → 500. `BuildError: Could not build url for endpoint 'consultancy_module'`. This predates the `academy_module`/`consultancy_module` routes existing at all (added later at `smc_base.py` lines 3020–3027) — a stale/superseded log. |
| `flask_stderr_capture.log` | 2026-09-19 22:27:28 | `/academy/ielts`, `/consultancy/clients` → 500. `BuildError: Could not build url for endpoint 'xedit'` / `'xadd'`. Root cause: the shared `xlist()` renderer (used by every academy/consultancy listing page) called `url_for('xadd', ...)` / `url_for('xedit', ...)`, but only `xadd_route` / `xedit_route` / `xlist_route` / `xdelete_route` are actually registered with `@app.route` (lines 3030–3047). The plain names were never valid endpoints. |

`smc_base.py` was last saved at **22:28:30** — one minute *after* that stderr capture. I checked the current
file directly: every `url_for(...)` call for this generator now correctly uses `xadd_route` / `xedit_route` /
`xlist_route` / `xdelete_route` (confirmed at lines 2696, 2751, 2814, 2870, 2911, 2929, 2949, 2991, 3006, 3014).

**So: as shipped in this zip, this specific bug looks fixed.** But there is no log captured *after* the 22:28
save, so it has not actually been re-tested. This needs one real request to each of `/academy/ielts` and
`/consultancy/clients` to confirm before treating it as closed — since the IELTS module is exactly the one
the guide lists as "in progress."

### A4. Database mismatch — needs your confirmation before anything else touches data
This is the most important finding and I have not acted on it.

The app's hardcoded database path (used identically in `smc_base.py`, `unified_app.py`, and
`analytics_base.py`) is:
```
C:\Users\Md Shakil Hossain\ShakilAI\websites\student_management\students.db
```
The `students.db` bundled at the root of this zip — which corresponds to that same path — contains
**29 tables, and every content table has 0 rows** (only `users` has 1 row). By contrast, the most recent
timestamped backup in the zip, `students_backup_20260919_235113.db` (copied 2026-09-19 23:51), has
**48 tables** and real records: 2 students, 2 teachers, 8 admissions, 4 attendance rows, 2 exams, fees,
routines, premium course data, etc.

Two explanations are possible and I can't tell which from the files alone:
1. The live `students.db` on your machine really is this empty/older schema, and the 19 newer tables
   (premium courses, `academy_ielts`, `academy_batches`, `consultancy_offers`, `blog_posts`, etc.) plus
   all the real records only exist in that backup — meaning a restore may be needed.
2. This zip's `students.db` is simply a stale copy that got swept up in the export (e.g. locked file, or an
   older snapshot), and the real live database with current data lives only on the Windows machine and
   wasn't part of what you sent me.

**I have not touched any `.db` file.** Please confirm which is true before I (or anything) writes to a
database — per the guide's own Database & Data Safety Rules ("back up before schema changes," "identify the
current database type before changing it").

### A5. Dead / orphaned code (confirmed unreachable, zero risk to remove, not yet removed)
- **`unified_server.py`** + **`unified_server_phase2_backup.py`** — see A2 (port collision risk, not just dead weight).
- **`analytics_base.py`** creates its own separate `Flask(__name__)` instance and registers two routes
  (including a second, colliding `/`) on it. `unified_app.py` only imports the plain functions `get_data`
  and `HTML` from this file, never its `app` — so these routes, and the file's own
  `if __name__=="__main__": app.run(port=7100)` block, never run. Leftover from the pre-unification
  microservice layout.
- **`dashboard_bridge_temp.py`** — not imported anywhere in the project. Registers `/smc` and `/smc/`,
  duplicating identical dead code already sitting *after* `app.run()` at the bottom of `unified_app.py`
  (lines 489–496, which is therefore also unreachable — Python never returns from a blocking `app.run()`
  call to register routes written below it).
- Eleven `smc_base_before_*.py` snapshots in the project root, plus a further eight inside `backup/`, plus
  seven `unified_app_before_*.py` snapshots — these are valuable history, not bugs, but confirm there is
  no real version control (see A7).

Full detail, including exact line numbers, is in `ROUTE_INVENTORY.md`.

### A6. Duplicate route registration (currently harmless, worth knowing)
`/premium-courses/admin/enrollments` is registered twice for the same URL: once in `smc_base.py`
(endpoint `premium_admin_enrollments`) and again in `unified_app.py` with an explicit
`endpoint="unified_premium_admin_enrollments"` override that just calls the same function. The comment
above it (`# ===== PREMIUM ENROLLMENTS LIVE ROUTE FIX =====`) indicates this was a hot-patch layered on top
rather than an edit inside `smc_base.py` itself. Flask allows two different endpoint names to map to one
URL, so this isn't currently broken — just a second place someone would have to remember to update.

### A7. No git repository in this zip
`.git` does not exist anywhere in the upload. Safety currently relies entirely on manually timestamped
`*_before_*.py` files and `.db` backups, which is exactly what the guide's Rule 2 ("Backup first") and the
Testing Checklist's "Git" row are meant to replace. This is the biggest structural gap relative to the
guide's own rules, and it's the one I'd recommend fixing first, since every other rule ("small changes,"
"reversible," "commit only after tests pass") depends on git existing.

### A8. Smaller, low-risk gaps
- No `requirements.txt` / `Pipfile` / `pyproject.toml`. Observed imports across the three live modules:
  `flask`, `werkzeug`, `requests`, `qrcode`. Nothing pinned, so a clean machine can't `pip install -r
  requirements.txt` to reproduce the environment.
- Secret key handling in `smc_base.py` is actually done correctly already: it reads `SHAKIL_AI_SECRET`
  from the environment, only falls back to a random per-run key in dev mode (with a printed warning), and
  raises `RuntimeError` if unset outside dev — this already matches Rule 7 ("never hard-code secrets"). No
  action needed here.
- Several hardcoded absolute Windows paths (`C:\Users\Md Shakil Hossain\...`) are repeated across
  `smc_base.py`, `unified_app.py`, and `analytics_base.py` instead of being defined once. Not a bug today,
  but if the project ever moves machine or folder, it breaks in three places at once instead of one.

---

## B. Files / routes this audit covered

| File | Role | Status |
|---|---|---|
| `unified_app.py` | Live entry point (port 7200) | Audited in full |
| `smc_base.py` | Live core app, 101 routes | Audited in full |
| `analytics_base.py` | Two functions reused; own app/routes dead | Audited in full |
| `unified_server.py` | Legacy stub, same port, **not currently used** | Flagged — port collision risk |
| `dashboard_bridge_temp.py` | Orphaned, unimported | Flagged — safe to remove |
| `students.db` + 6 timestamped backups | Data layer | Flagged — mismatch needs your confirmation |
| `check_db_schema.py` | Manual diagnostic script | Reviewed, no issue |
| 20 `patch_*.py` files in project root | One-off migration scripts, not imported by anything | Historical record only |
| 19 `*_before_*.py` snapshots (root + `backup/`) | Manual backups | Historical record only |

Complete per-route table (101 + 13 + 4 dead): **`ROUTE_INVENTORY.md`**.

---

## Recommended next steps, in order

1. **Confirm the database question (A4)** — this blocks everything else that touches data. One sentence
   from you (e.g. "the zip's `students.db` is stale, the real one has current data") is enough to close it.
2. **Set up git** — `git init`, a `.gitignore` (excluding `*.db`, `__pycache__/`, `*.log`, `premium_uploads/`),
   and one initial commit of the current state as a real rollback point. Purely additive, touches no
   application behavior, and is the single highest-value change available right now given A7.
3. **Resolve the port-7200 ambiguity (A2)** — rename or archive `unified_server.py` so there's one
   unambiguous way to start the server.
4. **Re-test `/academy/ielts` and `/consultancy/clients` (A3)** to confirm the endpoint-name fix actually
   holds, now that we know what to check.
5. Everything else in A5/A6/A8 is low-priority cleanup — worth doing, nothing here is urgent or risky.

I haven't made any of these changes yet. Tell me which one to start with (or say "just do 1–3, they're safe")
and I'll follow the guide's own workflow for it: smallest change → test → show you the diff → your commit.
